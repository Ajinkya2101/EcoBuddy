from flask import Flask, render_template, request
from dotenv import load_dotenv
import openai
from PyPDF2 import PdfReader
import os

load_dotenv()

app = Flask(__name__)

openai.api_key = os.getenv("OPENAI_API_KEY")


def get_pdf_text(pdf_docs):
    text = ""
    for pdf in pdf_docs:
        pdf_reader = PdfReader(pdf)
        for page in pdf_reader.pages:
            text += page.extract_text()
    return text


def ask_gpt(user_question):
    response_gpt = openai.Completion.create(
        model="gpt-3.5-turbo-instruct",
        prompt=user_question,
        temperature=1,
        max_tokens=200,
        n=1,
        stop=None,
        presence_penalty=0,
        frequency_penalty=0.1,
    )
    return response_gpt.choices[0].text.strip()


@app.route('/', methods=['GET', 'POST'])
def chat():
    gpt_response = None

    if request.method == 'POST':
        user_question = request.form['user_input']
        gpt_response = ask_gpt(user_question)

    return render_template('index.html', gpt_response=gpt_response)


if __name__ == '__main__':
    app.run(debug=True)
