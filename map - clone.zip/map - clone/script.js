mapboxgl.accessToken = 'pk.eyJ1Ijoic2FydmVzaC0zIiwiYSI6ImNscno3a3IzbzFnNjMyam14ODYzNW4wN2cifQ.b0BbVkdrz1UmFEEPG5qtAw';

const map = new mapboxgl.Map({
    container: 'map', // container ID
    style: 'mapbox://styles/mapbox/streets-v11', // style URL
    center: [72.8777, 19.0760], // starting position [lng, lat]
    zoom: 10 // starting zoom
});



// Initialize the Geocoder
map.on('load', function() {
    const geocoder = new MapboxGeocoder({
        accessToken: mapboxgl.accessToken,
        mapboxgl: mapboxgl,
        marker: false, // Set marker to false to disable placing a marker
        placeholder: 'Search for places',
    });

    document.getElementById('geocoder').appendChild(geocoder.onAdd(map));
});


let markers = []; // Array to store the saved coordinates
let temporaryMarker = null; // To store the current placemark not yet saved

// Add a placemark on map click but do not save it immediately
map.on('click', function (e) {
    const coordinates = [e.lngLat.lng, e.lngLat.lat];

    // Remove previous temporary marker if it exists
    if (temporaryMarker) {
        temporaryMarker.remove();
    }

    // Create a new temporary marker and add it to the map
    temporaryMarker = new mapboxgl.Marker()
        .setLngLat(coordinates)
        .addTo(map);
});

// Save button functionality
document.getElementById('saveButton').addEventListener('click', function () {
    const eventTitle = document.getElementById('eventTitle').value;
    const eventDescription = document.getElementById('eventDescription').value;
    if (temporaryMarker && eventTitle.trim() !== '' && eventDescription.trim() !== '') {
        const coordinates = temporaryMarker.getLngLat();

        // Create a popup for the saved marker that includes the event title and description
        const popup = new mapboxgl.Popup({ closeButton: true, closeOnClick: true })
            .setHTML('<h4>' + eventTitle + '</h4><p>' + eventDescription + '</p>');

        // Convert the temporary marker to a permanent marker by re-adding it with a popup
        const permanentMarker = new mapboxgl.Marker()
            .setLngLat([coordinates.lng, coordinates.lat])
            .setPopup(popup) // Associate the popup with the marker
            .addTo(map);

        // Setup hover event listeners to show/hide the popup
        const markerElement = permanentMarker.getElement();
        markerElement.addEventListener('mouseenter', () => permanentMarker.getPopup().addTo(map));
        markerElement.addEventListener('mouseleave', () => permanentMarker.getPopup().remove());

        // Clear the temporary marker so it can't be saved again
        temporaryMarker.remove();
        temporaryMarker = null;

        // Clear the input and textarea after saving the event
        document.getElementById('eventTitle').value = '';
        document.getElementById('eventDescription').value = '';
    } else {
        alert('Please place a marker, enter an event title, and enter an event description before saving.');
    }
});

